function animinfo() {
    let zentinfo = document.querySelectorAll(".animinfo");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }

  function foodinfo1() {
    let zentinfo = document.querySelectorAll(".foodinfo1");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }

  function foodinfo2() {
    let zentinfo = document.querySelectorAll(".foodinfo2");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }

  function foodinfo3() {
    let zentinfo = document.querySelectorAll(".foodinfo3");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }

  function foodinfo4() {
    let zentinfo = document.querySelectorAll(".foodinfo4");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }

  function foodinfo5() {
    let zentinfo = document.querySelectorAll(".foodinfo5");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }



  // //////////////////////////////////////////////////////

  function menuinfo1() {
    let zentinfo = document.querySelectorAll(".menuinfo1");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }


  function menuinfo2() {
    let zentinfo = document.querySelectorAll(".menuinfo2");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }
  function menuinfo3() {
    let zentinfo = document.querySelectorAll(".menuinfo3");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }
  function menuinfo4() {
    let zentinfo = document.querySelectorAll(".menuinfo4");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }
  function menuinfo5() {
    let zentinfo = document.querySelectorAll(".menuinfo5");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }

  function menuinfo6() {
    let zentinfo = document.querySelectorAll(".menuinfo6");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }

  function menuinfo7() {
    let zentinfo = document.querySelectorAll(".menuinfo7");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }

  function menuinfo8() {
    let zentinfo = document.querySelectorAll(".menuinfo8");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }
  // ////////////////////////////////////

  function chefinfo1() {
    let zentinfo = document.querySelectorAll(".chefinfo1");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }

  function chefinfo2() {
    let zentinfo = document.querySelectorAll(".chefinfo2");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }

  function chefinfo3() {
    let zentinfo = document.querySelectorAll(".chefinfo3");
  
    zentinfo.forEach(element => {
      if (element.style.display === 'none' || element.style.display === '') {
        element.style.display = 'flex';
      } else {
        element.style.display = 'none';
      }
    });
  }

